#include <z80.h>
#include <arch/zxn.h>
#include <intrinsic.h>
#include <arch/zxn/esxdos.h>
#include <errno.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common/build.h"
#include "common/d3.h"
#include "common/startup.h"

#include "util/parse_octal.h"

#include "untar/untar.h"

int main(int argc, char **argv)
{
    startup();

    unsigned char tar_in;

    tar_in = esxdos_f_open(*argv[1], "rb");

    if(errno) exit(errno);

    if (tar_in == NULL)
        printf("Unable to open %s\n", *argv);
    else {
        untar(tar_in, *argv);
        esxdos_f_close(tar_in);
    }

    exit(errno);
}